# Spotify-Clone
This project is a Spotify clone created using HTML and CSS, aiming to replicate the popular music streaming service's user interface and design. The clone offers users a familiar and intuitive interface for exploring music, creating playlists, and enjoying their favorite songs

  TECH USED
> HTML ||
> CSS

![image](https://github.com/sainath161/Spotify-Clone/assets/71361447/cfe3f79a-4e0b-4193-b8f7-33a065db00d8)

![image](https://github.com/sainath161/Spotify-Clone/assets/71361447/2de0da7c-6f33-41ac-85ff-b554f93dee88)
